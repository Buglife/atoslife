
        /* -ls as --print-lines-short assigned 300 */
        case 300:
            {
            /* FIXME implement */
            break;
            }

        /* -ta as --print-static assigned 301 */
        case 301:
            {
            /* FIXME implement */
            break;
            }

        /* -tf as --print-static-func assigned 302 */
        case 302:
            {
            /* FIXME implement */
            break;
            }

        /* -tv as --print-static-var assigned 303 */
        case 303:
            {
            /* FIXME implement */
            break;
            }

      /* --print-str-offsets assigned 304 */
        case 304:
            {
            /* FIXME implement */
            break;
            }

        /* -#<num> as --debug-tracelevel=<n> assigned 305 */
        case 305:
            {
            /* FIXME implement */
            break;
            }

        /* -oa as --reloc-abbrev assigned 306 */
        case 306:
            {
            /* FIXME implement */
            break;
            }

        /* -or as --reloc-aranges assigned 307 */
        case 307:
            {
            /* FIXME implement */
            break;
            }

        /* -of as --reloc-frames assigned 308 */
        case 308:
            {
            /* FIXME implement */
            break;
            }

        /* -oi as --reloc-info assigned 309 */
        case 309:
            {
            /* FIXME implement */
            break;
            }

        /* -ol as --reloc-line assigned 310 */
        case 310:
            {
            /* FIXME implement */
            break;
            }

        /* -oo as --reloc-loc assigned 311 */
        case 311:
            {
            /* FIXME implement */
            break;
            }

        /* -op as --reloc-pubnames assigned 312 */
        case 312:
            {
            /* FIXME implement */
            break;
            }

        /* -oR as --reloc-ranges assigned 313 */
        case 313:
            {
            /* FIXME implement */
            break;
            }

        /* -Ea as --elf-abbrev assigned 314 */
        case 314:
            {
            /* FIXME implement */
            break;
            }

        /* -Er as --elf-aranges assigned 315 */
        case 315:
            {
            /* FIXME implement */
            break;
            }

        /* -Ed as --elf-default assigned 316 */
        case 316:
            {
            /* FIXME implement */
            break;
            }

        /* -Ef as --elf-frames assigned 317 */
        case 317:
            {
            /* FIXME implement */
            break;
            }

        /* -Eh as --elf-header assigned 318 */
        case 318:
            {
            /* FIXME implement */
            break;
            }

        /* -Ei as --elf-info assigned 319 */
        case 319:
            {
            /* FIXME implement */
            break;
            }

        /* -El as --elf-line assigned 320 */
        case 320:
            {
            /* FIXME implement */
            break;
            }

        /* -Eo as --elf-loc assigned 321 */
        case 321:
            {
            /* FIXME implement */
            break;
            }

        /* -Ep as --elf-pubnames assigned 322 */
        case 322:
            {
            /* FIXME implement */
            break;
            }

        /* -Et as --elf-pubtypes assigned 323 */
        case 323:
            {
            /* FIXME implement */
            break;
            }

        /* -ER as --elf-ranges assigned 324 */
        case 324:
            {
            /* FIXME implement */
            break;
            }

        /* -Es as --elf-strings assigned 325 */
        case 325:
            {
            /* FIXME implement */
            break;
            }

        /* -Ex as --elf-text assigned 326 */
        case 326:
            {
            /* FIXME implement */
            break;
            }

        /* -kb as --check-abbrev assigned 327 */
        case 327:
            {
            /* FIXME implement */
            break;
            }

        /* -ka as --check-all assigned 328 */
        case 328:
            {
            /* FIXME implement */
            break;
            }

        /* -kM as --check-aranges assigned 329 */
        case 329:
            {
            /* FIXME implement */
            break;
            }

        /* -kD as --check-attr-dup assigned 330 */
        case 330:
            {
            /* FIXME implement */
            break;
            }

        /* -kE as --check-attr-encodings assigned 331 */
        case 331:
            {
            /* FIXME implement */
            break;
            }

        /* -kn as --check-attr-names assigned 332 */
        case 332:
            {
            /* FIXME implement */
            break;
            }

        /* -kc as --check-constants assigned 333 */
        case 333:
            {
            /* FIXME implement */
            break;
            }

        /* -kF as --check-files-lines assigned 334 */
        case 334:
            {
            /* FIXME implement */
            break;
            }

        /* -kR as --check-forward-refs assigned 335 */
        case 335:
            {
            /* FIXME implement */
            break;
            }

        /* -kx as --check-frame-basic assigned 336 */
        case 336:
            {
            /* FIXME implement */
            break;
            }

        /* -kxe as --check-frame-extended assigned 337 */
        case 337:
            {
            /* FIXME implement */
            break;
            }

        /* -kf as --check-frame-info assigned 338 */
        case 338:
            {
            /* FIXME implement */
            break;
            }

        /* -kg as --check-gaps assigned 339 */
        case 339:
            {
            /* FIXME implement */
            break;
            }

        /* -kl as --check-loc assigned 340 */
        case 340:
            {
            /* FIXME implement */
            break;
            }

        /* -kw as --check-macros assigned 341 */
        case 341:
            {
            /* FIXME implement */
            break;
            }

        /* -ke as --check-pubnames assigned 342 */
        case 342:
            {
            /* FIXME implement */
            break;
            }

        /* -km as --check-ranges assigned 343 */
        case 343:
            {
            /* FIXME implement */
            break;
            }

        /* -kS as --check-self-refs assigned 344 */
        case 344:
            {
            /* FIXME implement */
            break;
            }

        /* -kd as --check-show assigned 345 */
        case 345:
            {
            /* FIXME implement */
            break;
            }

        /* -ks as --check-silent assigned 346 */
        case 346:
            {
            /* FIXME implement */
            break;
            }

        /* -ki as --check-summary assigned 347 */
        case 347:
            {
            /* FIXME implement */
            break;
            }

        /* -kr as --check-tag-attr assigned 348 */
        case 348:
            {
            /* FIXME implement */
            break;
            }

        /* -kt as --check-tag-tag assigned 349 */
        case 349:
            {
            /* FIXME implement */
            break;
            }

        /* -ky as --check-type assigned 350 */
        case 350:
            {
            /* FIXME implement */
            break;
            }

        /* -kG as --check-unique assigned 351 */
        case 351:
            {
            /* FIXME implement */
            break;
            }

        /* -ku as --check-usage assigned 352 */
        case 352:
            {
            /* FIXME implement */
            break;
            }

        /* -kuf as --check-usage-extended assigned 353 */
        case 353:
            {
            /* FIXME implement */
            break;
            }

        /* -x line5=<selection> as --format-linetable-read-type=<sel> assigned 354 */
        case 354:
            {
            /* FIXME implement */
            break;
            }

        /* -u<file> as --format-file=<file> assigned 355 */
        case 355:
            {
            /* FIXME implement */
            break;
            }

        /* -H<num> as --format-limit=<num> assigned 356 */
        case 356:
            {
            /* FIXME implement */
            break;
            }

        /* -c<str> as --format-producer=<str> assigned 357 */
        case 357:
            {
            /* FIXME implement */
            break;
            }

        /* -cg as --format-gcc assigned 358 */
        case 358:
            {
            /* FIXME implement */
            break;
            }

        /* -cs as --format-snc assigned 359 */
        case 359:
            {
            /* FIXME implement */
            break;
            }

        /* -x groupnumber=<n> as --format-group=<n> assigned 360 */
        case 360:
            {
            /* FIXME implement */
            break;
            }

        /* -x noprintsectiongroups as --format-no-print_section_groups assigned 361 */
        case 361:
            {
            /* FIXME implement */
            break;
            }

        /* -x nosanitizestrings as --format-no-sanitize-strings assigned 362 */
        case 362:
            {
            /* FIXME implement */
            break;
            }

        /* -O file=<path> as --file-output=<path> assigned 363 */
        case 363:
            {
            /* FIXME implement */
            break;
            }

        /* -x abi=<abi> as --file-abi=<abi> assigned 364 */
        case 364:
            {
            /* FIXME implement */
            break;
            }

        /* -x name=<path> as --file-config=<path> assigned 365 */
        case 365:
            {
            /* FIXME implement */
            break;
            }

        /* -x tied=<path> as --file-tied=<path> assigned 366 */
        case 366:
            {
            /* FIXME implement */
            break;
            }

        /* -S any=<text> as --search-any=<text> assigned 367 */
        case 367:
            {
            /* FIXME implement */
            break;
            }

        /* -Svany=<text> as --search-any-count=<text> assigned 368 */
        case 368:
            {
            /* FIXME implement */
            break;
            }

        /* -S match=<text> as --search-match=<text> assigned 369 */
        case 369:
            {
            /* FIXME implement */
            break;
            }

        /* -Svmatch=<text> as --search-match-count=<text> assigned 370 */
        case 370:
            {
            /* FIXME implement */
            break;
            }

        /* -S regex=<text> as --search-regex=<text> assigned 371 */
        case 371:
            {
            /* FIXME implement */
            break;
            }

        /* -Svregex=<text> as --search-regex-count=<text> assigned 372 */
        case 372:
            {
            /* FIXME implement */
            break;
            }

        /* -Wp as --search-print-parent assigned 373 */
        case 373:
            {
            /* FIXME implement */
            break;
            }

        /* -Wc as --search-print-children assigned 374 */
        case 374:
            {
            /* FIXME implement */
            break;
            }

        /* -vv as --verbose-more assigned 375 */
        case 375:
            {
            /* FIXME implement */
            break;
            }
